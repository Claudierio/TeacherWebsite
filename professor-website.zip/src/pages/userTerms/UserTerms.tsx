import React from "react";

export default function UserTerms() {
  return (
    <div>
      <h1>User Terms Page</h1>
    </div>
  );
}